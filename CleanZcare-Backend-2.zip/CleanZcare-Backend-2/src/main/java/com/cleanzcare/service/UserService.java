package com.cleanzcare.service;

import java.util.List;

import com.cleanzcare.dto.UserDTO;

public interface UserService {
    List<UserDTO> getAllUsers();
}
