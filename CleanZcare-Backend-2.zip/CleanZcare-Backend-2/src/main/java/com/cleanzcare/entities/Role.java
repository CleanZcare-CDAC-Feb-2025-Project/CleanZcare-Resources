package com.cleanzcare.entities;

public enum Role {
    ADMIN,
    PROVIDER,
    USER
}
